package com.ibm.convertCurrency.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;

import com.ibm.convertCurrency.feign.client.CurrencyFeignClient;


@Service
public class ConvertCurrencyService {

	@Autowired
	CurrencyFeignClient feignClient; 
	
	@Autowired
	DiscoveryClient discoveryClient;
	
	@Autowired
	LoadBalancerClient loadBalancerClient;
	
	//Service call with Rest template
	public double getConversionFactor(String countryCode) {
		String url = "http://localhost:8081/find/"+countryCode; 
		System.out.println("URL is "+ url);
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(url, String.class);
		System.out.println("result is "+ result);
		return Double.parseDouble(result);
		
	}
	//Service call with Rest template with Loadbalancer
		public double getConversionFactorWithLoadBalancer(String countryCode) {
			
			ServiceInstance instance = loadBalancerClient.choose("conversionFactorMS");
			String url = "http://" + instance.getHost() + ":" + instance.getPort() + "/find/"+countryCode;
			System.out.println("Ribbon URL " + url);
			RestTemplate restTemplate = new RestTemplate();
			String result = restTemplate.getForObject(url, String.class);
			System.out.println("result is "+ result);
			return Double.parseDouble(result);
			
		}
	
	//Service call with FeignClient
	public double getConversionFactorWithFeign(String countryCode)
	{
		Double result = feignClient.getConversionFactor(countryCode);
		return result;
	}

	
}
