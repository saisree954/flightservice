package com.ibm.convertCurrency.model;

public class CurrencyConvertDTO {

}
