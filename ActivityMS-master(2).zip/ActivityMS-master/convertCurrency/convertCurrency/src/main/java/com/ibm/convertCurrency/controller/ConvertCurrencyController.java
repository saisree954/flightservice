package com.ibm.convertCurrency.controller;

import java.util.Date;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.convertCurrency.service.ConvertCurrencyService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class ConvertCurrencyController {

	@Autowired
	ConvertCurrencyService service;
	
	//Using RestTemplate
	@RequestMapping(value="/convertV1/{countryCode}/{amount}", method = RequestMethod.GET)
	public double convertCurrency(@PathVariable String countryCode, @PathVariable double amount) {
		double conversionFactor = service.getConversionFactor(countryCode);
		return conversionFactor*amount;
	}
	
	//Using Feign Client
	@HystrixCommand(fallbackMethod = "getConversionFactorWithFeignFallback")
	@RequestMapping(value="/convert/{countryCode}/{amount}", method = RequestMethod.GET)
	public String convertCurrencyWithFeign(@PathVariable String countryCode, @PathVariable double amount) {
		double conversionFactor = service.getConversionFactorWithFeign(countryCode);
		return String.valueOf(conversionFactor*amount);
	}
	
	//Using RestTemplate & ribbon load balancer
		@HystrixCommand(fallbackMethod = "getConversionFactorWithFeignFallback")
		@RequestMapping(value="/convertLb/{countryCode}/{amount}", method = RequestMethod.GET)
		public String convertCurrencyWithLB(@PathVariable String countryCode, @PathVariable double amount) {
			double conversionFactor = service.getConversionFactorWithLoadBalancer(countryCode);
			return String.valueOf(conversionFactor*amount);
		}
	
	public String getConversionFactorWithFeignFallback(@PathVariable String countryCode, @PathVariable double amount) 
	{
		return "CIRCUIT BREAKER ENABLED!!! No Response From ConversionFactor Service at this moment. " +
                " Service will be back shortly - " + new Date();
	}
	
	//Testing purspose
	@RequestMapping(value="/test", method = RequestMethod.GET)
	public String test() {
		return "hello world";
	}
}
