package com.ibm.CurrencyConversionfactor.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.ibm.CurrencyConversionfactor.model.CurrencyConversionFactorModel;

public interface CurrencyConversionFactorRepository extends JpaRepository<CurrencyConversionFactorModel,String>{

}
