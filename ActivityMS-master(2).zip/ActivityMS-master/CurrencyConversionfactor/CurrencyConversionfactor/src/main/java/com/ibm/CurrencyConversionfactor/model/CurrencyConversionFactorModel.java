package com.ibm.CurrencyConversionfactor.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="CurrencyConversion")
public class CurrencyConversionFactorModel {

	@Id
	private String countryCode;
	private double conversionfactor;
	
	public CurrencyConversionFactorModel(String countryCode, double conversionfactor) {
		super();
		this.countryCode = countryCode;
		this.conversionfactor = conversionfactor;
	}
	public CurrencyConversionFactorModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public double getConversionfactor() {
		return conversionfactor;
	}
	public void setConversionfactor(double conversionfactor) {
		this.conversionfactor = conversionfactor;
	}	

}
