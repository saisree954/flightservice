package com.ibm.CurrencyConversionfactor.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ibm.CurrencyConversionfactor.model.CurrencyConversionFactorModel;
import com.ibm.CurrencyConversionfactor.repository.CurrencyConversionFactorRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class CurrencyConversionFactorService {

	@Autowired
	CurrencyConversionFactorRepository repo;
	
	//CurrencyConversionFactorModel currencyModel;
	//to add conversionFactor and countryCode to db
		public void add (String countryCode, Double conversionFactor) {
			
			repo.save(new CurrencyConversionFactorModel(countryCode,conversionFactor));
		}
		
		//To get all records
		public List<CurrencyConversionFactorModel> getAll()
		{ //List<ConversionFactor> ConversionFactors = new ArrayList<>();
				//repo.findAll().forEach(ConversionFactors::add);
					return repo.findAll();
		}
		//To get records by id
		public CurrencyConversionFactorModel getConversionFactor(String countryCode)
		{
			Optional<CurrencyConversionFactorModel> optConversionFactor = repo.findById(countryCode);
			
			if (optConversionFactor != null)
			{
				return optConversionFactor.get();
			}
			else
				return null;
			
		}
		
		//To update
		public void update(String countryCode, Double conversionFactor) {
			if(repo.existsById(countryCode)) {
				CurrencyConversionFactorModel countryCodeToUpdate = repo.getOne(countryCode);
				countryCodeToUpdate.setCountryCode(countryCode);
				countryCodeToUpdate.setConversionfactor(conversionFactor);
				repo.save(countryCodeToUpdate);
			}
			else {
				add(countryCode, conversionFactor);
			}	
		}
		
}
