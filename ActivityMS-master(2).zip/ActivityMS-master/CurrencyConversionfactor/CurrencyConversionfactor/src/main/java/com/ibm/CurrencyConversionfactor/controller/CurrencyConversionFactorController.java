package com.ibm.CurrencyConversionfactor.controller;

import java.util.List;
import java.util.NoSuchElementException;

import javax.el.MethodNotFoundException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.HttpEntityMethodProcessor;

import com.ibm.CurrencyConversionfactor.model.CurrencyConversionFactorModel;
import com.ibm.CurrencyConversionfactor.service.CurrencyConversionFactorService;



@RestController
public class CurrencyConversionFactorController {
	
	@Autowired
	CurrencyConversionFactorService service;
	
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public String getTestMessage()
	{
		return "Hello world";
		}
	
	@RequestMapping(value = "/add/{countryCode}/{conversionFactor}", method = RequestMethod.POST)
	public HttpStatus addConversionFactor(@PathVariable String countryCode, @PathVariable double conversionFactor, HttpServletResponse httpResponse) {
		
		service.add(countryCode, conversionFactor);
		return HttpStatus.CREATED;
	}
	
	@RequestMapping(value = "/find", method = RequestMethod.GET)
	public List<CurrencyConversionFactorModel> getAll()
	{
		return service.getAll();
		}
	
	@RequestMapping(value = "/find/{countryCode}", method = RequestMethod.GET)
	public Double getConversionFactor(@PathVariable String countryCode) {
		try {
		CurrencyConversionFactorModel conversionFactorRecord = service.getConversionFactor(countryCode);
		return conversionFactorRecord.getConversionfactor();}
		catch (NoSuchElementException exc) {
	         throw new ResponseStatusException(
	           HttpStatus.NOT_FOUND, "Record Not Found", exc);
	    }
	}
	@RequestMapping(value = "/update/{countryCode}/{conversionFactor}", method = RequestMethod.PUT)
	public HttpStatus updateConversionFactor(@PathVariable String countryCode, @PathVariable double conversionFactor) {
		
		service.update(countryCode, conversionFactor);
		return HttpStatus.OK;
		
	}
	
}
